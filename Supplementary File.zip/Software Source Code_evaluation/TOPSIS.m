clc, clear
a=xlsread('Data.xlsx');
[m,n]=size(a);
b=a./vecnorm(a)   
w=[0.0835 0.0657 0.1107 0.0781 0.0363 0.0931 0.0943 0.3812 0.0570];
c=b.*w;             
Cstar=max(c);      
C0=min(c);            
Sstar=vecnorm(c-Cstar,2,2)  
S0=vecnorm(c-C0,2,2)        
f=S0./(Sstar+S0)
[sf,ind]=sort(f,'descend')     
