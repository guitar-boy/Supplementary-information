clear
clc
x=xlsread('Data.xlsx');
num=1000;
iter=50;
n=size(x,2);
wmax=0.5;wmin=0.01; 

w=[0.0835 0.0657 0.1107 0.0781 0.0363 0.0931 0.0943 0.3812 0.0570];
sub=0.8*w;
up=1.2*w; 

c=[];
for i=1:10000
    c(i,:)=sub+rand.*(up-sub);
    c(i,:)=c(i,:)./sum(c(i,:));
    y(i,1)=Target(x,c(i,:));
end
[y,b]=sort(y,'descend');
c=c(b,:);
y=y(1:num,1);
c=c(1:num,:);
bestc=c(1,:);
besty=y(1);
trace=besty;
cc=[];
yy=[];
v=rand(num,9);
for i=1:iter
    fave=mean(y);
    fmax=max(y);
    for j=1:num
        if y(j)>fave
            w=wmin+(fmax-y(j))*(wmax-wmin)/(fmax-fave);
        else
            w=wmax;
        end
        v(j,:)=w*v(j,:)+rand*(bestc-c(j,:)); 
        cc(j,:)=c(j,:)+v(j,:);
        cc(j,:)=max(cc(j,:),sub);
        cc(j,:)=min(cc(j,:),up);
        cc(j,:)=cc(j,:)./sum(cc(j,:));
        yy(j,1)=Target(x,cc(j,:));
    end
    Y=[];
    C=[];
    Y=[y;yy];
    C=[c;cc];
    [Y,b]=sort(Y,'descend');
    C=C(b,:);
    y=Y(1:num,:);
    c=C(1:num,:);
    bestc=c(1,:);
    besty=y(1);
    trace=[trace,besty];
end
disp('Optimal Weight')
disp(bestc)
disp('Evaluation Value')
P=x*bestc'
figure
plot(trace)
xlabel('Number of Iterations')
ylabel('G Function')
title('The PSO-PPE Method')