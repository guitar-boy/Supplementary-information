clc
clear
x=xlsread('Data.xlsx');
[n,m]=size(x);
abc=[1 1 1 1 1 1 2 1 1];
for i=1:m
    if abc(i)==1 
        X(:,i)=normalize(x(:,i),1,0.002,0.996);
    else         
        X(:,i)=normalize(x(:,i),2,0.002,0.996);
    end
end

for i=1:n
    for j=1:m
        p(i,j)=X(i,j)/sum(X(:,j));
    end
end

k=1/log(n);
for j=1:m
    e(j)=-k*sum(p(:,j).*log(p(:,j)));
end
g=ones(1,m)-e;
w=g./sum(g);
w=w';