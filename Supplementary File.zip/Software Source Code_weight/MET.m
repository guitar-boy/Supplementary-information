clc
clear
w=xlsread('weight.xlsx');   
[m,n]=size(w);              

for i=1:m
    E1(i,:)=sum(w(i,1:2))/2;   
    E2(i,:)=sum(w(i,3:4))/2;   
    a(i,:)=E1(i,:)/(E1(i,:)+E2(i,:));   
    b(i,:)=E2(i,:)/(E1(i,:)+E2(i,:));   
end

a=sum(a)/m;
b=sum(b)/m;

w0= zeros(m,1);
Aeq=ones(m,1)';
beq=1;
lb= zeros(m,1);
ub= ones(m,1);
[W,y]=fmincon('fun1',w0,[],[],Aeq,beq,lb,ub,[],[])
for i=1:m
    W(i,:)=E1(i,:)*a+E2(i,:)*b
end
W