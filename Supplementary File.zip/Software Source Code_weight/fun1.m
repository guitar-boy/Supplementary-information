function f = fun1(W)
w=xlsread('weight.xlsx');   
[m,n]=size(w);                

for i=1:m
    E1(i,:)=w(i,1:2)/2;   
    E2(i,:)=w(i,3:4)/2;   
    a(i,:)=E1(i,:)/(E1(i,:)+E2(i,:));  
    b(i,:)=E2(i,:)/(E1(i,:)+E2(i,:));   
end

a=sum(a)/m;
b=sum(b)/m;

for i=1:m
    f=a*sum((W(i)-w(i,1))^2)+b*sum((W(i)-w(i,2))^2);
end
end

