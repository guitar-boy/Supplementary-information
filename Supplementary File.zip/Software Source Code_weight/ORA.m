clc
clear
CmpVec=[1/3 1 1 3/1 1/5 1 1/3 5];

n=length(CmpVec)+1;
sumr=0;
for i=1:length(CmpVec)
    prodr=1;
    for j=i:length(CmpVec)
        prodr=prodr*CmpVec(j);
    end
    sumr=sumr+prodr;
end
W(n,1)=1/(1+sumr);
for i=length(CmpVec):-1:1
    W(i,1)=W(i+1,1)*CmpVec(i)
end
