clc
clear
x=xlsread('Data.xlsx');

stdBycols=std(x); 
cort=corrcoef(x); 
f=zeros(9,1); 
for j=1:9 
    f(1,1)=9-sum(cort(j,1)); 
    f(2,1)=9-sum(cort(j,2));
    f(3,1)=9-sum(cort(j,3)); 
    f(4,1)=9-sum(cort(j,4)); 
    f(5,1)=9-sum(cort(j,5)); 
    f(6,1)=9-sum(cort(j,6)) 
    f(7,1)=9-sum(cort(j,7)); 
    f(8,1)=9-sum(cort(j,8));  
    f(9,1)=9-sum(cort(j,9));
end 

f=f'  
C=zeros(9,1); 
for i=1:9 
    C(i,1)=stdBycols(1,i)*f(1,i); 
end 
Csum=sum(C); 
D=zeros(9,1); 
for i=1:9 
    for j=10-i
        D(i,1)=C(j,1)/Csum
    end
end

