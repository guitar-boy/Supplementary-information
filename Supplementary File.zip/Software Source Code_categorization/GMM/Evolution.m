clc
clear
x=xlsread('Data.xlsx');
T=xlsread('GMM.xlsx');

for i=1:9
    eva_SC_i= evalclusters(x,T(:,i),'silhouette');
    eva_CHI_i= evalclusters(x,T(:,i),'CalinskiHarabasz');
    eva_DBI_i= evalclusters(x,T(:,i),'DaviesBouldin');
    
    SC_i = eva_SC_i.CriterionValues; 
    CHI_i = eva_CHI_i.CriterionValues;
    DBI_i = eva_DBI_i.CriterionValues; 
    
    SC(i) = SC_i;
    CHI(i) = CHI_i;
    DBI(i) = DBI_i;
end
SC = SC';
CHI = CHI';
DBI= DBI';