clear all
clc
addpath('fcm')
X = xlsread('Data.xlsx');

c = 10;
metric = @euclidean;
m = 1.5;
Max = 1000;
tol = 1e-3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Data Normalization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nr nc] = size(X);
for i = 1:nc
   for j = 1:nr
     data(j, i) = (X(j, i)-std(X(:, i)))/mean(X(:, i));
   end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Running the Algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%***************FCM************************
[prediction,v] = fcm(c, data, m, metric, Max, tol);
%v
%prediction
prediction=prediction';