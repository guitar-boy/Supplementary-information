clear all;
close all;

X=xlsread('Data.xlsx');

c = 10; 
alpha = 0.5;
k = 5;
[Label, Cluster] = CURE(X, alpha, c, k);       
