clc
clear
X=xlsread('Data1.xlsx');
c = 5; 
alpha = 0.3;
k = 5;
[Label, Cluster] = CURE(X, alpha, c, k);   

% figure
% subplot(1,2,1);
% plot(X(:,1),X(:,2),'.');
% subplot(1,2,2);
% PlotClusterinResult(X, Label);