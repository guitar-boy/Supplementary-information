clear
clc
data = xlsread('Data.xlsx');

%%KNN k distance graph, to determine the epsilon
%����k����ͼ����ȷ��0.15Ϊ���ʺϵ�Eps����ֵ
A=data;
numData=size(A,1);
Kdist=zeros(numData,1);
[IDX,Dist]=knnsearch(A(2:numData,:),A(1,:));
Kdist(1)=Dist;
for i=2:size(A,1)
    [IDX,Dist] = knnsearch(A([1:i-1,i+1:numData],:),A(i,:));
    Kdist(i)=Dist;
end
[sortKdist,sortKdistIdx]=sort(Kdist,'descend');
distX=[1:numData]';
plot(distX,sortKdist,'r+-','LineWidth',2);
title('K distance graph');
set(gcf,'position',[1000 340 350 350]);
grid on;

%% DBSCAN
SimMatrix=pdist2(data,data,'minkowski',2);
eps=0.4;
MinPts=3;
Tclass=Mdbscan(data,MinPts,eps,SimMatrix)'

eva_DBI_1= evalclusters(data,Tclass,'DaviesBouldin');
eva_SC_1= evalclusters(data,Tclass,'silhouette');
eva_CHI_1= evalclusters(data,Tclass,'CalinskiHarabasz');

DBI_1 = eva_DBI_1.CriterionValues; 
SC_1 = eva_SC_1.CriterionValues; 
CHI_1 = eva_CHI_1.CriterionValues; 